# -*- coding: utf-8 -*-

# Various helper functions

import glob
import os
import re
import sys
import time
import unicodedata
import urllib
from urllib.parse import urlparse
from urllib.parse import quote_plus

import xbmcvfs

from prelogging import Prelogger


# Fixes unicode problems
def string_unicode(text, encoding='utf-8'):
    try:
        if sys.version_info[0] >= 3:
            text = str(text)
        else:
            text = unicode(text, encoding)
    except:
        pass
    return text


def normalize_string(_string):
    try:
        text = unicodedata.normalize('NFKD', unicode(string_unicode(_string))).encode('ascii', 'ignore')
    except:
        pass
    return text


# Returns list of arguments passed to HTTP GET request
def get_params(param_string):
    return urllib.parse.parse_qs(param_string)


# Returns string suitable for passing as HTTP GET parameter
def get_quoted_str(param_string):
    return quote_plus(param_string)


def get_cache_dir_title(param_string):
    filename = secure_dirname(param_string)
    return filename


# Required for determining flag
def get_language_list(param_string):
    lang_list = param_string.split(",")
    langs_map = {
        "Bosnian": ("bs", 32019,),
        "Croatian": ("hr", 32016,),
        "English": ("en", 32013,),
        "Serbian": ("sr", 32015,),
        "Serbian (Cyrillic)": ("cirilica", 32014,),
        "German": ("de", 32017,),
        "Serbo-Croatian": ("sh", 32018,)
    }
    ret_map = dict()
    for lang in lang_list:
        if lang in list(langs_map.keys()):
            ret_map[langs_map[lang][0]] = langs_map[lang][1]
    return ret_map


# Returns subtitle candidate name
def get_subtitle_candidate(file_path, lang, ext=''):
    # Get just filename
    filename = file_path.split('/')[-1]
    return ".".join(filename.split('.')[:-1] + [lang, ext])


# Returns possible subtitles for given media and language
def get_possible_subtitles(cache_dir, file_path, language):
    candidate = get_subtitle_candidate(file_path, language, '*')
    subtitle_mask = os.path.join(cache_dir, candidate)
    return glob.glob(subtitle_mask)


# Remove subdirectories from given directory
# that are older than N days
def remove_older_than(top_level, days):
    def remove(path):
        if os.path.isdir(path):
            try:
                os.rmdir(path)
            except OSError:
                raise Exception("Unable to remove folder '{0}'".format(path))
        else:
            try:
                if os.path.exists(path):
                    os.remove(path)
            except OSError:
                raise Exception("Unable to remove file '{0}'".format(path))

    time_in_secs = time.time() - (days * 24 * 60 * 60)
    items = list()
    for root, dirs, files in os.walk(top_level, topdown=False):
        for file_ in files:
            full_path = os.path.join(root, file_)
            stat = os.stat(full_path)
            if stat.st_mtime <= time_in_secs:
                remove(full_path)
                items.append(full_path)
        if not os.listdir(root):
            remove(root)
            items.append(root)
    return items

def get_root(path):
    format = path.lower().split('.')[-1]
    path = quote_plus(path)
    return format + '://' + path + '/'

def get_subtitle_file(path):
    dirs, files = xbmcvfs.listdir(get_root(path))
    return files[0]

def unzip(path, dest):
    file = get_subtitle_file(path)
    root = get_root(path)
    unzip_file(os.path.join(root, file), os.path.join(dest, file))

def unzip_file(path, dest):
    ''' Unzip specific file. Path should start with zip:// or rar://
    '''
    xbmcvfs.copy(path, dest)
    
def secure_dirname(dirname):
    INVALID_FILE_CHARS = '/\\?%*:|"<>' # https://en.wikipedia.org/wiki/Filename#Reserved_characters_and_words
    
    # keep only valid ascii chars
    output = list(unicodedata.normalize("NFKD", dirname))

    # special case characters that don't get stripped by the above technique
    for pos, char in enumerate(output):
        if char == '\u0141':
            output[pos] = 'L'
        elif char == '\u0142':
            output[pos] = 'l'

    # remove unallowed characters
    output = [c if c not in INVALID_FILE_CHARS else '_' for c in output]
    return "".join(output).encode("ASCII", "ignore").decode()